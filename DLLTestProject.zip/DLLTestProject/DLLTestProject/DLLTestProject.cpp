#include <iostream>
#include "DLLTestProject.h"
 
int Add( int a, int b )
{
   return( a + b );
}
 
void Function( void )
{
   std::cout << "THIS IS COMING FROM INSIDE THE DLL! HOLY SHIT" << std::endl;
}