#ifndef _DLL_TUTORIAL_H_
#define _DLL_TUTORIAL_H_
#include <iostream>
 
int Add( int a, int b );
void Function( void );

#endif