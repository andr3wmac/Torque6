#include <iostream>
#include <windows.h>
 
typedef int (*AddFunc)(int,int);
typedef void (*FunctionFunc)();
 
int main()
{
   AddFunc _AddFunc;
   FunctionFunc _FunctionFunc;
   HINSTANCE hInstLibrary = LoadLibrary(TEXT("DLLTestProject.dll"));
 
   if (hInstLibrary)
   {
      _AddFunc = (AddFunc)GetProcAddress(hInstLibrary, "Add");
      _FunctionFunc = (FunctionFunc)GetProcAddress(hInstLibrary,
         "Function");
 
      if (_AddFunc)
      {
         std::cout << "ADDING NUMBERS WITH DLL FUNCTION: 124 + 78 = " << _AddFunc(124, 78) << std::endl;
      }
      if (_FunctionFunc)
      {
         _FunctionFunc();
      }
 
      FreeLibrary(hInstLibrary);
   }
   else
   {
      std::cout << "DLL Failed To Load!" << std::endl;
   }
 
   std::cin.get();
 
   return 0;
}